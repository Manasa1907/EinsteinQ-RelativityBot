Scope of Project
The system helps to retrieve accurate and reliable answers for the queries by the
user related to physics concepts, mainly Theory of Relativity. If the relevant
answer isn’t available, the system just responds that the relevant answer isn’t
available and asks the user to refrain from the question or provide more
information on the same to retrieve accurate answers.

Data Source
The required data is collected from the research paper related to Theory of Relativity.
This is obtained from the web source.

Conclusion
The system is able to retrieve the accurate results for the queries related to theory of relativity. 

